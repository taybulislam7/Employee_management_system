<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/iCheck/square/blue.css">
  <style>
	#bgd{
		background-image: url(/img/Background.jpg);
		background-repeat: no-repeat;
		background-size: 1580px 900px;
		background-color: darkseagreen;

	}
	#login{
		background-color: #B8F3E5;
		float: left;
		margin-left:120px;
		border-radius:15px;
		margin-top: 70px;
		width:570px;
		border: 1px solid #026458;
		box-shadow: -15px -15px 15px rgba(255,255,255,0.2),
					15px 15px 15px rgba(0,0,0,0.3);
	}
	#login2{
		background-color: #B8F3E5;
		border-radius:15px;
		height:450px;
		
	}
	#logo{
		margin-top:90px;
		font-family: Baloo;
	}
	#uname{
		border-radius: 10px;
		width: 484px;;
		margin-left:20px;
		padding: 20px;
		margin-top: 10px;
		opacity: 0.5;
		font-size: 24px;
		border: 1px solid #026458;
		box-shadow: -15px -15px 15px rgba(255,255,255,0.2),
					15px 15px 15px rgba(0,0,0,0.3);
	}
	#uname2{
		width: 97px;
		height: 40px;
		opacity: 0.5;
		line-height: 41px;
	}
	#pass{
		border-radius: 10px;
		width: 484px;
		margin-left:20px;
		margin-top: 50px;
		padding: 20px;
		font-size: 24px;
		opacity: 0.5;
		border: 1px solid #026458;
		box-shadow: -15px -15px 15px rgba(255,255,255,0.2),
					15px 15px 15px rgba(0,0,0,0.3);
	}
	#pass2{
		width: 97px;
		height: 40px;
		opacity: 0.5;
		line-height: 41px;
	}
	#signin{
		font-size: 18px;
		background-color: #5CD4B8;
		margin-top: 80px;
		font-family: Baloo;
		text-align: center;
		margin-left: 180px;
		border-radius:15px;
		box-shadow: -15px -15px 15px rgba(255,255,255,0.2),
					15px 15px 15px rgba(0,0,0,0.1);
		
	}
	#signin:hover{
		opacity:0.6;
	}
	#error{
		color: red;
		margin-left: 50px;
	}
	
  </style>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body id="bgd">
<div class="login-box" id="login">
  <div class="login-logo" id="logo">
    <a href="#" style="color:#026458"><b>LOGIN</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body" id="login2">

    <?php echo form_open('Home/login'); ?>
      <div class="form-group has-feedback">
        <input type="text" name="txtusername" class="form-control" id="uname" placeholder="Email">
        <span class="glyphicon glyphicon-user form-control-feedback" id="uname2"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" name="txtpassword" class="form-control" id="pass" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback" id="pass2"></span>
      </div>
	  <div id="error">
      <?php echo $this->session->flashdata('login_error'); ?>
	  </div>
      <div class="row">
        <!-- /.col -->
        <div class="col-xs-4 pull-left">
          <button type="submit" class="btn btn-success btn-block btn-flat" id="signin">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url(); ?>assets/plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
</body>
</html>

